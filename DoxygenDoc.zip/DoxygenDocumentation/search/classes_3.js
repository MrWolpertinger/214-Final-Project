var searchData=
[
  ['date_5ftime_0',['date_time',['../structdate__time.html',1,'']]],
  ['defensive_1',['Defensive',['../class_defensive.html',1,'']]],
  ['depth_5fcounter_5fscope_2',['depth_counter_scope',['../structdepth__counter__scope.html',1,'']]],
  ['designmodewarsimulation_3',['DesignModeWarSimulation',['../class_design_mode_war_simulation.html',1,'']]]
];
