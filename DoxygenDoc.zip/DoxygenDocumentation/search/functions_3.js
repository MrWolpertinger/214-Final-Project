var searchData=
[
  ['damagesummary_0',['damageSummary',['../class_transportation_corridor.html#a5872b50cd162d9e074be47906ea5c58f',1,'TransportationCorridor']]],
  ['dechp_1',['decHP',['../class_air_force.html#a1ba15318308aa33140138e2ae7046fe6',1,'AirForce::decHP()'],['../class_ground_force.html#abe5f4d0700db21ffe917f53ae3b0be7b',1,'GroundForce::decHP()'],['../class_navy.html#a0e96f567680c850b5bd0eae424f07ee6',1,'Navy::decHP()']]],
  ['defeat_2',['defeat',['../class_country.html#a4a6163ee7f86ba1094642f3777bb7875',1,'Country::defeat()'],['../class_transportation_corridor.html#a268c695509be7af0470b9c199eb90b8c',1,'TransportationCorridor::defeat()']]]
];
