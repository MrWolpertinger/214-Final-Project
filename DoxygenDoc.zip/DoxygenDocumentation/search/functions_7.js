var searchData=
[
  ['inchp_0',['incHP',['../class_air_force.html#ab0df7f839ac859f5d6187702ce4c247e',1,'AirForce::incHP()'],['../class_ground_force.html#ae72822a244071046b6cba275fef0d298',1,'GroundForce::incHP()'],['../class_navy.html#af6313a09a14fedf633073627e6948d0b',1,'Navy::incHP()']]],
  ['increasehp_1',['increaseHP',['../class_country.html#a715bd3ed120532e27fea1f3c42a493bd',1,'Country']]]
];
