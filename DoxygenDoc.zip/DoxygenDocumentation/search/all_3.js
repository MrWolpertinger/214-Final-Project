var searchData=
[
  ['damagesummary_0',['damageSummary',['../class_transportation_corridor.html#a5872b50cd162d9e074be47906ea5c58f',1,'TransportationCorridor']]],
  ['date_5ftime_1',['date_time',['../structdate__time.html',1,'']]],
  ['dechp_2',['decHP',['../class_air_force.html#a1ba15318308aa33140138e2ae7046fe6',1,'AirForce::decHP()'],['../class_ground_force.html#abe5f4d0700db21ffe917f53ae3b0be7b',1,'GroundForce::decHP()'],['../class_navy.html#a0e96f567680c850b5bd0eae424f07ee6',1,'Navy::decHP()']]],
  ['defeat_3',['defeat',['../class_country.html#a4a6163ee7f86ba1094642f3777bb7875',1,'Country::defeat()'],['../class_transportation_corridor.html#a268c695509be7af0470b9c199eb90b8c',1,'TransportationCorridor::defeat()']]],
  ['defensive_4',['Defensive',['../class_defensive.html',1,'']]],
  ['depth_5fcounter_5fscope_5',['depth_counter_scope',['../structdepth__counter__scope.html',1,'']]],
  ['designmodewarsimulation_6',['DesignModeWarSimulation',['../class_design_mode_war_simulation.html',1,'']]]
];
