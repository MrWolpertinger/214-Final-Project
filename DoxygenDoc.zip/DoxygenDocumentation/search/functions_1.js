var searchData=
[
  ['battle_0',['Battle',['../class_battle.html#a3f6d813a18609c2a5d962179ffa0414f',1,'Battle']]]
];
