var searchData=
[
  ['receivedamage_0',['receiveDamage',['../class_country.html#a078455d01b3785e10bb71af7307b99fa',1,'Country::receiveDamage()'],['../class_transportation_corridor.html#a0b3da72489bdb1c783955789b70143a2',1,'TransportationCorridor::receiveDamage()']]],
  ['remove_1',['remove',['../class_country_group.html#a727fb5de5dc2c332643d96b22f6fb84b',1,'CountryGroup']]],
  ['requestassistance_2',['requestAssistance',['../class_country.html#a700eef315f6024fe4250f39ae034b775',1,'Country']]],
  ['rifles_3',['Rifles',['../class_rifles.html#afc6ffa18a32a6ed4077689ca1fe16012',1,'Rifles']]]
];
