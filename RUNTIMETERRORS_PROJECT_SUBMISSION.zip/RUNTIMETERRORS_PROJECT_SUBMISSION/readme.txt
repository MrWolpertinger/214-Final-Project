How to compile and run the Runtime Terror's War Simulator.

1.) Extract the zip file.
2.) The program files and makefile will be in the System folder and the data file(s) will be in the Data folder.
3.) Open your terminal and set the current directory to the System folder.
4.) Look at the data file(s) and change the country number, troop information and weapons information if you want to.
5.) Type make and press Enter to compile the program.
6.) Type make run and press Enter to run the program.
7.) You will have to enter information to setup the program.