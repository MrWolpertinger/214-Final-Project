#include "gtest/gtest.h"
#include "DesignModeWarSimulation.h"

TEST(DesignModeTest, test1) {
    //arrange
    DesignModeWarSimulation *a = new DesignModeWarSimulation();
	a->setName("World War I");
    //act
    //assert
    EXPECT_TRUE (a->getName()==  "World War I");
    a->setName("World War II");
    EXPECT_TRUE (a->getName()==  "World War II");
}