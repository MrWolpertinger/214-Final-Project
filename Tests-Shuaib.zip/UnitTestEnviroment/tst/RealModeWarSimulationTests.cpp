#include "gtest/gtest.h"
#include "RealModeWarSimulation.h"

TEST(RealModeTest, test1) {
    //arrange
    RealModeWarSimulation *a = new RealModeWarSimulation();
	a->setName("Korean War");
    //act
    //assert
    EXPECT_TRUE(a->getName()==  "Korean War");
    a->setName("Korean War2");
    EXPECT_TRUE(a->getName()== "Korean War2");
}