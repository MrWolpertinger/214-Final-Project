 #include <iostream>
 #include "SimulationManager.h"
 #include "WarSimulation.h"
 #include "RealModeWarSimulation.h"
 #include "DesignModeWarSimulation.h"
 //#include "ConfigClass.h"


 using namespace std;


 int main() {

        DesignModeWarSimulation *a = new DesignModeWarSimulation();
	a->setName("World War I");
	 
	RealModeWarSimulation *b = new RealModeWarSimulation();
	b->setName("Korean War");
    
    return 0;
 }

 