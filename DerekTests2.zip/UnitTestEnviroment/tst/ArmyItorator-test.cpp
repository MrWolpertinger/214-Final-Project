#include "gtest/gtest.h"
#include "Military.h"
#include "ArmyItorator.h"

TEST(ArmyItoratorTest, test1) {
    Military *M = new Military();
    ArmyItorator* AI = M->createIterator();
    AI->add(new Navy(3,1,115));
    AI->add(new AirForce(1,5,30));
    //arrange
    //act
    //add 20 troops
    //assert

    //individual dmg %% HP
    EXPECT_EQ (AI->getHP(AI->firstItem()), (3*115));
    EXPECT_EQ (AI->getDMG(AI->nextItem()), (5*30));
}

TEST(ArmyItoratorTest, test2) {
    Military *M = new Military();
    ArmyItorator* AI = M->createIterator();
    AI->add(new Navy(3,1,115));
    AI->add(new AirForce(1,5,30));
    AI->add(new Navy(3,1,115));
    AI->add(new AirForce(1,5,30));
    AI->add(new Navy(3,1,115));
    AI->add(new AirForce(1,5,30));
    //arrange
    //act
    //add 20 troops
    //assert

    //different catagories
    //Totals
    EXPECT_EQ (AI->getCatagoryHP('N'), (3*115*3));
    EXPECT_EQ (AI->getCatagoryDMG('A'), (5*30*3));

    EXPECT_EQ (AI->getTotalHP(), (3*115*3 + 1*30*3));

    EXPECT_EQ (AI->getTotalDMG(), (1*115*3 + 5*30*3));
}