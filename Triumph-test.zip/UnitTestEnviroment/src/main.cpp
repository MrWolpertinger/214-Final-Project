#include <iostream>
#include "LightweightFactory.h"

int main1() {
    LightWeightFactory *LightFact = new LightWeightFactory();
    Weapons *Grenades = LightFact->produceGrenades(10,5);
    Weapons *Pistols = LightFact->producePistols(10,5);
    Weapons *Rifles = LightFact->produceRifles(10,5);
    Weapons *Machingun = LightFact->produceMachineGuns(10,5);

    cout << "Grenades Fired " << Grenades->fire() << endl;
    cout << "Pistols Fired " << Pistols->fire() << endl;
    cout << "Rifles Fired " << Rifles->fire() << endl;
    cout << "MachineGun Fired " << Machingun->fire() << endl;
    return 0;
}