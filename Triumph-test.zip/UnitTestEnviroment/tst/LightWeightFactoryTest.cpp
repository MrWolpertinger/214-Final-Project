#include <gtest/gtest.h>
#include "LightweightFactory.h"

TEST(lightWeightFactorytest, test1) {
    //arrange
    LightWeightFactory *LightFact = new LightWeightFactory();
    //act
    //assert
    Weapons *Grenades = LightFact->produceGrenades(10,5);
    Weapons *Pistols = LightFact->producePistols(15,10);
    Weapons *Rifles = LightFact->produceRifles(20,15);
    Weapons *Machingun = LightFact->produceMachineGuns(25,20);

    EXPECT_EQ (Grenades->fire(),  10);
    EXPECT_EQ (Pistols->fire(),  15);
    EXPECT_EQ (Rifles->fire(),  20);
    EXPECT_EQ (Machingun->fire(),  25);

    EXPECT_EQ (Grenades->getNum(),  5);
    EXPECT_EQ (Pistols->getNum(),  10);
    EXPECT_EQ (Rifles->getNum(),  15);
    EXPECT_EQ (Machingun->getNum(),  20);
    
}

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}