#include "gtest/gtest.h"
#include "Weapons.h"

TEST(Weaponstest , test1){
    Weapons* W = new Weapons();
    W->setName("AK47") ;
    EXPECT_TRUE (W->getName() ==  "AK47");
    W->setName("RPG") ;
    EXPECT_TRUE (W->getName() ==  "RPG");
}