#include "gtest/gtest.h"
#include "Country.h"

TEST(CountryTest , test1){
    Country *C = new Country("SA") ;
    C->setLeader("Cyril");

    EXPECT_TRUE (C->getLeader()==  "Cyril");
    C->setLeader("Bob");
    EXPECT_TRUE (C->getLeader()==  "Bob");

}