#include "gtest/gtest.h"
#include "CountryGroup.h"
#include "Country.h"
#include "CountryGroupIterator.h"
#include "AlliedForce.h"

TEST(CountryGroupTest, test1){
    Country* c = new Country("USA");
    CountryGroup* a = new CountryGroup("Allies");
    a->add(c);
    CountryGroupIterator* p = a->CreateGroupIterator();
	p->first();
    AlliedForce* check = p->current();
    EXPECT_EQ(check->getName(), "USA");
}