#include "gtest/gtest.h"
#include "Airspace_War_Theatre.h"
#include "Country.h"

TEST(Airspace_War_TheatreTest, test1) {
    //arrange
    AlliedForce *A1 = new Country("fsdf");
    AlliedForce *A2 = new Country("khvxcas");
    War_Theatre *a = new Airspace_war_theatre("asd",A1,A2);
    //act
    //assert
    EXPECT_EQ (a->getName(),  "asd");
    EXPECT_EQ (a->getType(), 1);
    War_Theatre *b = a->cloneTheatre();
    EXPECT_EQ (b->getName(),  "asd");
    EXPECT_EQ (b->getType(), 1);

    delete a;
    delete b;
    delete A1;
    delete A2;
}