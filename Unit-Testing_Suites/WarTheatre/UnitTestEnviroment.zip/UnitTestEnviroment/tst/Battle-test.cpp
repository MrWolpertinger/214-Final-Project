#include "gtest/gtest.h"
#include "Battle.h"
#include "Country.h"

TEST(BattleTest, test1) {
    //arrange
    Country *C1 = new Country("hapless");
    Country *C2 = new Country("nonononom");
    Battle *B = new Battle("dfsdf","00BC", "01AD", C1, C2, 'A');
    //act
    std::cout << B->getBattleDescription() << std::endl;
    //assert
    EXPECT_EQ (B->getBattleDescription(),  "Locale: The sky is difficult to fly in.\nSide A: hapless VS Side B: nonononom");

    delete B;
    delete C1;
    delete C2;
}