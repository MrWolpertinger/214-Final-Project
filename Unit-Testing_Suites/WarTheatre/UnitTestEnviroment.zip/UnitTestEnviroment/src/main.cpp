#include <iostream>
#include "Battle.h"
#include "Country.h"

int main() {
    AlliedForce *C1 = new Country("hapless");
    AlliedForce *C2 = new Country("nonononom");
    Battle *B = new Battle("dfsdf","00BC", "01AD", C1, C2, 'A');
    std::cout << C1->getName() << std::endl;
    std::cout << B->getBattleDescription();
    delete B;
    delete C1;
    delete C2;
    return 0;
}