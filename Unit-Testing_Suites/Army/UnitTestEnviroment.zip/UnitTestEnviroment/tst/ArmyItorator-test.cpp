#include "gtest/gtest.h"
#include "Military.h"
#include "ArmyItorator.h"

TEST(ArmyItoratorTest, test1) {
    Military *M = new Military();
    ArmyItorator* AI = M->createIterator();
    //arrange
    //act
    //add 20 troops
    //assert

    //different catagories
    //Totals
    //individual dmg %% HP
    EXPECT_EQ (Formula::bla (0),  0);
    EXPECT_EQ (Formula::bla (10), 20);
    EXPECT_EQ (Formula::bla (50), 100);
}